<?php
$timestamp = mt_rand(1, time());
$randomDate = date("d/m/Y", $timestamp);
$now = date("d/m/Y");
$date1 = explode('/',$now);
$year1 = $date1[2];
$date2 = explode('/',$randomDate);
$year2 = $date2[2];
$age= $year1 - $year2;
echo $now;
echo "---";
echo $randomDate;
echo "===";
echo $age;


?>