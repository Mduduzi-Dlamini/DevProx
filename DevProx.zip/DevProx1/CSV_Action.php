<?php       
// Generate CSV File from Array in PHP Script
function generate($rows){
    $names = array("Mduduzi Welcome", "Bianca", "Angelica", "Lisa Gabriella", "Mxolisi", "Kimberly", "Sizwe Isaac", "Esther", "Ryan", " Khaya Calvin", " Purity Chloë", "Jess", "Nina", "Andre", "James" , "Mary", "Patricia", "Michael", "John", "Tim");
    $surnames = array("Dlamini", "Jantjies", "Lewis", "Mokwena", "Brown", "Bester" , "Scott", "Smith", "Johnson", "Williams", "Davis", "Ndlovu", "Jacobs", "Zulu", "Venter", "Coetzee", "Mbatha", "Govender", "Mazibuko", "Ngwenya");
    $results = array();
    while (sizeof($results)!=$rows) {
        $person = create_person($names, $surnames); //array Id, name, surname...
        $id = sizeof($results)+1;
        if (check_person($person, $results, $names, $surnames)==true) {
            array_unshift($person, "$id");
            array_push($results,$person);
        }  
    }
    return $results;
}
//creating row lines as person
function create_person($names, $surnames){
    $q= rand(0,sizeof($names)-1);
    $r= rand(0,sizeof($surnames)-1);
    $name= $names[$q];
    $surname= $surnames[$r];
    $timestamp = mt_rand(1, time());
    $randomDate = date("d/m/Y", $timestamp);
    $now = date("d/m/Y");
    $date1 = explode('/',$now);
    $year1 = $date1[2];
    $date2 = explode('/',$randomDate);
    $year2 = $date2[2];
    $age= $year1 - $year2;
    $initials=getInitials($name);
    $person =array(  
        "Name" => "$name",  
        "Surname" => "$surname", 
        "Initials" => "$initials",
        "Age" => "$age",
        "DateOfBirth" => "$randomDate" 
    );
    return $person;
}
//getting initials from the name of a person
function getInitials($name){
    $init=substr($name, 0, 1);
    for ($i=0; $i < strlen($name); $i++) { 
        if ($name[$i]==" ") {
            $init=$init.substr($name, $i+1, 1);
        }  
    }
    return $init;
}
//unique person
function check_person($person, $results, $names, $surnames){
    foreach ($results as $value) {
        $array1 = array_values($value);
        $array2 = array_values($person);
        if($array1[0]==$array2[0] or $array1[1]==$array2[1]){
            return false;
        }
    }
    return true;
}
//creating a csv file
function download($num,$csv_file){
            
    $file = fopen($csv_file, "w");
    $results = generate($num);       
    $header = array_keys($results[0]);       
    fputcsv($file, $header);       
    foreach($results as $row)       
    {  
       fputcsv($file, $row);  
    }       
    fclose($file);
}
//upload table header
function uploadCSV_header($csv_file){
    $file = fopen($csv_file, "r");
    $header_arr = fgetcsv($file);
    $html='<table id="datatables-example" class="table table-striped table-bordered" width="100%" cellspacing="0">';
    $html.='<thead>';
    $html.='<tr>';
    foreach ($header_arr as $key => $value) {
        $html.='<th>'.$value.'</th>';
    }
    $html.='</tr>';
    $html.='</thead>';
    return $html;
}
//upload body header
function uploadCSV_body($csv_file){
    $file = fopen($csv_file, "r");
    $header_body = fgetcsv($file);
    $html='<tbody>';
    while ($line = fgetcsv($file)) {
        $html.='<tr>';
        foreach ($line as $key => $value) {
            $html.='<td>'.$value.'</td>';
        }
        $html.='</tr>';
    }
    
    $html.='</tbody>';
    $html.='</table>';
    return $html;
}


?>
