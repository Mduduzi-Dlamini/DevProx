<?php
    //
    //validate both ID length and if digits are integers
    function validateId($id_no){
        if (strlen($id_no)==13) {
            if(isAllNumbers($id_no)){
                return "ok";
            }
            else {
                return '
                <div class="col-md-12">
                    <div class="alert alert-danger alert-3d alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                     Your ID Number must contain  <strong> Numerical values only!</strong>.
                    </div>
                </div>';
                
            }
        }else {
            return '
                <div class="col-md-12">
                    <div class="alert alert-danger alert-3d alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                     ID Number Must be exactly <strong>13 digits!</strong>.
                    </div>
                </div>';
            
        }
    }
    //check if ID has Numerical values only
    function isAllNumbers($id_no){
        for ($i=0; $i < strlen($id_no); $i++) { 
            if (!is_numeric($id_no[$i])) {
                return false;
            } 
        }
        return true;
    }
    //conform Date of Birth
    function confirmDOB($id_no,$dob){
        $date = explode('/',$dob);
        $day = $date[0];
        $month = $date[1];
        $year = $date[2];
        if(($day==substr($id_no, 4, 2)) and ($month==substr($id_no, 2, 2)) and (substr($year, 2, 2)==substr($id_no, 0, 2)) ){
            return true;
        }
        else {
            return false;
        }


        
    }
    
    
?>

